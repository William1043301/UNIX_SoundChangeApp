#!/bin/sh
sudo apt-get install alsa-utils
sudo apt-get install ffmpeg
./bootstrap
./configure
make
sudo make install
exit 0
